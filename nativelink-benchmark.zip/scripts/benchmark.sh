#!/bin/bash
echo "Starting benchmark..."

echo "Benchmarking with remote cache only..."
bazel build //:your_target --remote_cache=https://app.nativelink.com

echo "Benchmarking with remote cache and remote execution..."
bazel build //:your_target --remote_cache=https://app.nativelink.com --remote_executor=https://app.nativelink.com

echo "Saving benchmark results..."
echo '{"remote_cache_only": "done", "remote_cache_exec": "done"}' > benchmark_results.json

echo "Benchmark complete."
